const AWS  = require('aws-sdk');
AWS.config.update({ region: process.env.AWS_REGION}); // update Region if needed
const dynamodb = new AWS.DynamoDB();

exports.handler = async (event) => {
    try {
        const params = {
            TableName: process.env.TABLE_NAME, 
            Key: {
                'short_url': { S: 'xdaszes' } // particion key
            }
        };
        // Read operations for the url
        const result = await dynamodb.getItem(params).promise();
        return result.Item;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
};






